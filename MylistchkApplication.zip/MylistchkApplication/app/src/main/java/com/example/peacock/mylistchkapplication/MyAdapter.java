package com.example.peacock.mylistchkapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

/**
 * Created by peacock on 6/14/16.
 */
public class MyAdapter extends BaseAdapter {
    private Context mcontext;
    private ViewHolder viewHolder;
    private List<ItemBean> mlist;
    private LayoutInflater mInflater;
    private static HashMap<Integer, Boolean> mapIsSelected;

    public MyAdapter(Context context, List<ItemBean> list) {
        mcontext = context;
        mlist = list;
        mInflater = LayoutInflater.from(context);
        mapIsSelected = new HashMap<>();
        initMapIsSelected();
    }

    private void initMapIsSelected() {
        for (int i = 0; i < mlist.size(); i++) {
            mapIsSelected.put(i, false);
        }
    }

    @Override
    public int getCount() {
        return mlist.size();
    }

    @Override
    public Object getItem(int position) {
        return mlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item, null);
            viewHolder.imageView = (ImageView) convertView.findViewById(R.id.imageview);
            viewHolder.textView = (TextView) convertView.findViewById(R.id.textview1);
            viewHolder.checkBox = (CheckBox) convertView.findViewById(R.id.checkbox);
            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ItemBean bean = mlist.get(position);
        viewHolder.imageView.setImageResource(bean.ItemPicId);
        viewHolder.textView.setText(bean.ItemTextView);
        viewHolder.checkBox.setText(bean.ItemCheckBox);
        viewHolder.checkBox.isChecked();

        viewHolder.checkBox.setChecked(getMapSelected().get(position));
        viewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("ddd", position + "");

                getMapSelected().put(position, !getMapSelected().get(position));
                if (getMapSelected().get(position)) {
                    MainActivity.selectNum++;
                } else {
                    MainActivity.selectNum--;
                }
                viewHolder.checkBox.setChecked(getMapSelected().get(position));
                MainActivity.text_num.setText("选中" + MainActivity.selectNum + "项");
            }
        });
        return convertView;
    }

    public static HashMap<Integer, Boolean> getMapSelected() {
        return mapIsSelected;
    }

    public static class ViewHolder {
        TextView textView;
        CheckBox checkBox;
        ImageView imageView;
    }
}
