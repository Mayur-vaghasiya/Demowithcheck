package com.example.peacock.mylistchkapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
    private ArrayList<Product> itemproduct;
    private mylistadapter mAdapter;
    private ListView listView;
    private CheckBox chkall;
    Button btn_sellectAll, btn_sellectBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        chkall = (CheckBox) findViewById(R.id.chkall);
        btn_sellectAll = (Button) findViewById(R.id.btn_selectAll);
        btn_sellectBack = (Button) findViewById(R.id.btn_selectBack);

        itemproduct = new ArrayList<Product>();
        itemproduct.add(new Product(R.drawable.pas," Listview With Checkbox",true));
        for (int i = 1; i <= 30; i++) {
            itemproduct.add(new Product(R.drawable.pas, " Text " + i, false));
        }
        mAdapter = new mylistadapter(Main2Activity.this, itemproduct);
        listView = (ListView) findViewById(R.id.mainListView);
        listView.setAdapter(mAdapter);
    }
}
