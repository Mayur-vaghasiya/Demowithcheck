package com.example.peacock.mylistchkapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private List<ItemBean> itemBeansList;
    public static int selectNum = 0;
    public static TextView text_num;
    private MyAdapter mAdapter;
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        selectNum = 0;
        text_num = (TextView)findViewById(R.id.textview_num);
        itemBeansList = new ArrayList<>();

        itemBeansList.add(new ItemBean(R.mipmap.ic_launcher,"Listview With Checkbox","yes"));
        for(int i = 1; i <= 30; i++){
            itemBeansList.add(new ItemBean(R.mipmap.ic_launcher,"Text"+i,"yes"));
        }

        mAdapter = new MyAdapter(MainActivity.this,itemBeansList);
        listView = (ListView)findViewById(R.id.mainListView);
        listView.setAdapter(mAdapter);

        Button btn_sellectAll =(Button)findViewById(R.id.btn_selectAll);
        Button btn_sellectBack =(Button)findViewById(R.id.btn_selectBack);
        Button btn_sellectNone =(Button)findViewById(R.id.btn_selectNone);
        btn_sellectAll.setOnClickListener(this);
        btn_sellectBack.setOnClickListener(this);
        btn_sellectNone.setOnClickListener(this);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MyAdapter.ViewHolder holder = (MyAdapter.ViewHolder)view.getTag();
                holder.textView.setText("Click");
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_selectAll:
                for(int i = 0; i < itemBeansList.size(); i++){
                    MyAdapter.getMapSelected().put(i,true);
                }
                selectNum = itemBeansList.size();
                break;
            case R.id.btn_selectBack:
                selectNum = 0;
                for(int i = 0; i < itemBeansList.size(); i++){
                    boolean selectState = MyAdapter.getMapSelected().get(i);
                    if(selectState == false){
                        selectNum ++;
                    }
                    MyAdapter.getMapSelected().put(i,!selectState);
                }
                break;
            case R.id.btn_selectNone:
                for(int i = 0; i < itemBeansList.size(); i++){
                    MyAdapter.getMapSelected().put(i,false);
                }
                selectNum = 0;
                break;
        }
        dataChanged();
    }
    private void dataChanged(){
        mAdapter.notifyDataSetChanged();
        text_num.setText("xxx" + selectNum + "x");
    }


}

