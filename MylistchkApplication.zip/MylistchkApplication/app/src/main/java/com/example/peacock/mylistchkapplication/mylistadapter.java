package com.example.peacock.mylistchkapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by peacock on 6/14/16.
 */
public class mylistadapter extends BaseAdapter {
    public Context context;
    ArrayList<Product> myproduct;

    mylistadapter(Context context, ArrayList<Product> myproduct) {
        this.context = context;
        this.myproduct = myproduct;
    }

    @Override
    public int getCount() {
        return myproduct.size();
    }

    @Override
    public Object getItem(int position) {
        return myproduct.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        LayoutInflater layoutinflater;
        if (convertView == null) {
            layoutinflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView=layoutinflater.inflate(R.layout.listitem,null);
            holder=new Holder();
            holder.imageView=(ImageView)convertView.findViewById(R.id.imageview1);
            holder.textView=(TextView)convertView.findViewById(R.id.txtview1);
            holder.checkBox=(CheckBox)convertView.findViewById(R.id.chkbox1);
            convertView.setTag(holder);


        } else {
            holder=(Holder)convertView.getTag();
        }
        Product p = myproduct.get(position);
        holder.imageView.setImageResource(p.ItemPicId);
        holder.textView.setText(p.name);
        holder.checkBox.setChecked(p.check);
        holder.checkBox.isChecked();
        return convertView;
    }

    public static class Holder {
        TextView textView;
        CheckBox checkBox;
        ImageView imageView;
    }
}
