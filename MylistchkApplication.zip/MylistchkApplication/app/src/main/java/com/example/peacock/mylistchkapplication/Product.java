package com.example.peacock.mylistchkapplication;

/**
 * Created by peacock on 6/14/16.
 */
public class Product {
    private String name;
    private boolean check;
    private int ItemPicId;

    Product(int ItemPicId, String Name, boolean Check) {
        this.ItemPicId=ItemPicId;
        this.name=Name;
        this.check=Check;
    }

    public void setName(String name){
        this.name=name;
    }

    public String getName(){
        return  name;
    }

    public void setItemPicId(int imgid){
        this.ItemPicId=imgid;
    }
    public int getItemPicId(){
        return ItemPicId;
    }

    public void  setCheck(boolean check){
        this.check=check;
    }
}