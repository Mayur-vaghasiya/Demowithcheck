package com.example.peacock.mylistchkapplication;

/**
 * Created by peacock on 6/14/16.
 */
public class ItemBean {
    public String ItemTextView;
    public int ItemPicId;
    public String ItemCheckBox;

    public ItemBean(int ItemPicId, String ItemTextView, String ItemCheckBox) {
        this.ItemPicId = ItemPicId;
        this.ItemTextView = ItemTextView;
        this.ItemCheckBox = ItemCheckBox;
    }
}
